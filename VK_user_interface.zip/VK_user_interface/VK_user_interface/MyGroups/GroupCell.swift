//
//  GroupCell.swift
//  VK_user_interface
//
//  Created by Виталий Степушин on 10.12.2020.
//

import UIKit

class GroupCell: UITableViewCell {

    @IBOutlet weak var groupName: UILabel!
    
}
