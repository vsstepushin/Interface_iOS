//
//  ViewController.swift
//  VK_user_interface
//
//  Created by Виталий Степушин on 03.12.2020.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

